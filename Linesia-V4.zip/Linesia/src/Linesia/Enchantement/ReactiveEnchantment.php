<?php

namespace Linesia\Enchantement;

use Linesia\Enchantement\Traits\ReactiveTrait;

class ReactiveEnchantment extends CustomEnchant {
    use ReactiveTrait;
}