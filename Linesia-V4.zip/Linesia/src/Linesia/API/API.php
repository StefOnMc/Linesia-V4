<?php

namespace Linesia\API;

abstract class API {



}