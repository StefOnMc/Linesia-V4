<?php

namespace Linesia\Libs\refaltor\inventoryapi\inventories\type;

interface InventoryTypeIds{

    public const TYPE_WORKBENCH = "portablecrafting:workbench";
    public const TYPE_HOPPER = "invmenu:hopper";

}