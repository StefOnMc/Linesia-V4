<?php

namespace Linesia\Task;


class TaskManager {

    public static function initTask() : void {


    }
}