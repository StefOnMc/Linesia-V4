<?php

namespace Linesia\Entity;

final class EntityNbt {

    const TAG_ISNPC = "IsNpc";
    const TAG_CUSTOMNAME = "NpcCustomName";
    const TAG_COMMANDS = "NpcCommands";

}