<?php

namespace Linesia\Entity\NPC;

use Linesia\Entity\Base\BaseCustomEntity;

class HumanNpc extends BaseCustomEntity {



}