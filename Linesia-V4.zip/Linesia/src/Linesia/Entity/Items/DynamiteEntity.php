<?php

namespace Linesia\Entity\Items;

use pocketmine\entity\projectile\Snowball;

class DynamiteEntity extends Snowball {
}