<?php

namespace Linesia\Entity;

use pocketmine\entity\Human;

class HumanEntity extends Human {
    use NPCEntity;
}